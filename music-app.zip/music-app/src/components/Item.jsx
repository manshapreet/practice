import { useState } from "react";
export const Item= ({fn, item})=>{
    console.log(item);
    const [playerFlag,setPlayerFlag ]=useState(false);
    
    const showPlayer=()=>
   { fn(true, item);

}

    return(
        <div className="row">
            <div className="col-4">
                <img src={item.artworkUrl100}/>
            </div>
            <div className="col-4">
            {item.artistName}{item.trackName}
            </div>
            <div className="col-4">
            <button onClick={showPlayer} className='btn btn-primary'>
            play song

            </button>
            </div>


   
    </div>
    )

}