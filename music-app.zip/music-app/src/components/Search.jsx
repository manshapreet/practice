import {useRef} from "react";
export const Search =({fn}) =>{

    const Name=useRef();

    return (
        <>
        <label> Artist Name </label>
        
        <input ref={Name}type='text' className='form-control' placeholder='Search Anything'/>
        
        <button className="btn btn-success" onClick={()=>{
            fn(Name.current.value);}}> Search It </button>
       
       </>
    );
}