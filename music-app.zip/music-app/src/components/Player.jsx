export const Player=({fn ,item})=>{
    console.log('song?', item);
    return (
    <div>
        <br/>

        <button onClick={()=> {
            fn(false,null);
        }} className="btn btn-success"> back </button> 
        <p>
        <img src={item.artworkUrl100}/>
        <br />
            Singer Name: {item?.artistName}
        </p>
        
        <br/>

        <audio controls>
        <source src={item?.previewUrl} type="audio/mp4"/>
        </audio>
       
        </div>
        )
}