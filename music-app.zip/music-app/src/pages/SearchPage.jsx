import { useEffect } from 'react';
import { useState } from 'react';
import React from 'react'
import { Search } from '../components/Search.jsx'
import { Items } from '../components/Items.jsx';
import { getItems } from '../Services/api-client.js';
import { Player } from '../components/Player.jsx';

export const SearchPage = () => {
  
  const [allItems,setItems] = useState([]);
  
  //life cycle
  const[flag,setFlag]=useState(false);
    const [item, setitem]= useState(null);

  const loadItems=async()=>{
    setItems(await getItems('latest Items'));
  }
  useEffect(()=>{
    loadItems();},[])

  const togglePlayer=(flag,itemarg)=>{
    setitem(itemarg);
      setFlag(flag);
    }
  const getName = async(Name)=>{
    console.log('Name',Name);
    setItems(await getItems(Name));
  }
  
  const jsx=<>
  <Search fn={getName}/>
  <Items fn={togglePlayer} allItems ={allItems} />
  </>
  
  return ( 
    <>
    <div className='container'>
        <h1 className='alert alert-success'> Spotify </h1>
       
    {flag?<Player fn={togglePlayer} item={item}/>:jsx}
    
    </div>
    </>
  );
}
