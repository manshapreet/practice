import axios, { Axios } from 'axios';
export async function getItems(Name){
    const URL=`https://itunes.apple.com/search?term=${Name}&limit=25.`
    const response = await axios.get(URL);
    console.log(response.data['results']);
    return response.data['results'];
}